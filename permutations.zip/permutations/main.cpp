
//Problem

#include <iostream>
#include <string>
using namespace std;

const int MAXRESULTS = 30000;

int permutator(string prefix, string rest, string results[], int &index);
bool helperCheckResult(int i, int max, string array[], string word);
void permutatorLoop(string &prefix, string &rest, string results[], int &index, int i);



int main()
{
 
    string word = "ABCD";
    string results[MAXRESULTS];
    int i = 0;
    int index = 0;
    int p = permutator("", "asdfghi", results, index);
    cout << p << endl;
    
//    for(int i = 0; i < MAXRESULTS; i++)
//    {
//        if(results[i] != "")
//        cout << results[i] << endl;
//    }
    return 0;
}

//this function checks if a word is in the RESULTS array
bool helperCheckResult(int i, int max, string array[], string word)
{
    if (i >= max)
        return false;
    
    
    //FIXME: dont know if i can have this bracket
    
    //if the word
    if(array[i] == word)
    {
        return true;
    }

    //iterate the index
    return helperCheckResult(i + 1, max, array, word);
 
}


void permutatorLoop(string &prefix, string &rest, string results[], int &index, int i)
{
    if(i >= rest.size())
        return;
    
    string indexLetter = rest.substr(i,1);
    string restWithoutFirstPOST = rest.substr(i + 1);
    string restWithoutFirstPRE = rest.substr(0,i);
    
    string preRestRemove = rest;
    string prePrefixAdd = prefix;
    
    prefix += indexLetter;
    rest = restWithoutFirstPRE + restWithoutFirstPOST;
    
    string word = prefix + rest;
    
    
    if(!helperCheckResult(0, MAXRESULTS, results, word))
    {
        if(results - index == 0)
        {
            
        }
        results[index] = word;
        index++;
    }
    
    permutator(prefix, rest, results, index);
    
    prefix = prePrefixAdd;
    rest = preRestRemove;
    
    i += 1;
    permutatorLoop(prefix, rest, results, index, i);
    
    
}

//remove last letter in prefix, add it to beginning of rest
//remove first letter in rest, add it to end of prefix
//count must start at 0 (for the loop)
int permutator(string prefix, string rest, string results[], int &index)
{
    int i = 0;
    permutatorLoop(prefix, rest, results, index, i);
    return index;
}



