
#include <iostream>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;



int makeDictionary(istream &dictfile, string dict[]);
int helperMakeDict(istream &dictfile, int j, string dict[], int max);
int shuffleChars(string word, const string dict[], int size, string results[]);
int permutator(string prefix, string rest, string results[], int &index,  const string dict[], int &size);
bool helperCheckResult(int i, int max, string array[], string word);
void permutatorLoop(string &prefix, string &rest, string results[], int &index, int i, const string dict[], int &size);
bool helperCheckWord(int i, int max, const string array[], string word);
void revealOutcomes(const string results[], int size);



//change later. Don't think I can keep it.
const int MAXRESULTS = 20 ;
const int MAXDICTWORDS = 50000;



int main() {
    string results[MAXRESULTS];
    string dict[MAXDICTWORDS];
    ifstream dictfile;         // file containing the list of words
    int nwords;                // number of words read from dictionary
    string word;

    dictfile.open("test.txt");
    if (!dictfile) {
        cout << "File not found!" << endl;
        return (1);
    }

    nwords = makeDictionary(dictfile, dict);
    cout << nwords << endl;

    
    for(;;)
    {
    cout << "Please enter a string for an anagram: ";
    cin >> word;

    int numMatches = shuffleChars(word, dict, nwords, results);
    cout << numMatches << endl;
    if (!numMatches)
        cout << "No matches found" << endl;
    else
        revealOutcomes(results, numMatches);

    }
    return 0;

}


//Puts each string in dictfile into the array dict. Returns the number of words
//read into dict. This number should not be larger than MAXDICTWORDS since that is
//the size of the array.
int makeDictionary(istream &dictfile, string dict[])
{
    //this helper auxiliary function helps keep track of numbers, in which make dictionary can not.
    return helperMakeDict(dictfile, 0,  dict, MAXDICTWORDS);

}



//this helper auxiliary function helps keep track of numbers, in which make dictionary can not.
int helperMakeDict(istream &dictfile, int j, string dict[], int max)
{
    //cant exceed max, also j+1 will account for index 0
    if(j+1 > max)
    {
        return max;     //will continuously return max
    }
    
    //if end of file, stop counting and adding words.
    if(dictfile.eof())
    {
        return j;   //return number of recursions up to then
    }
    else            //keep on inputting words into the dictionary
    {
        string word;
        getline(dictfile, word);
        dict[j] = word;
        
        //want to return number of elements, j
        return helperMakeDict(dictfile, j + 1, dict, MAXDICTWORDS);

    }
}


//this function checks if a word is in the dictionary
bool helperCheckWord(int i, int max, const string array[], string word)
{
    if (i >= max)
        return false;
    
    //word is in dictionary
    if(array[i] == word)
    {
        return true;
    }

    //iterate the index
    return helperCheckWord(i + 1, max, array, word);
 
}



//Puts all the possibilities of word which are found in dict into results. Returns
//the number of matched words found. This number should not be larger than
//MAXRESULTS since that is the size of the array. The size is the number of words
//inside the dict array.
int shuffleChars(string word, const string dict[], int size,
                 string results[]){
    
    string rest = word;
    string prefix = "";
    int index = 0;
    
    //helper permutator function to keep track of indeces
    return permutator("", rest, results, index, dict, size);
}



//remove last letter in prefix, add it to beginning of rest
//remove first letter in rest, add it to end of prefix
//count must start at 0 (for the loop)
int permutator(string prefix, string rest, string results[], int &index, const string dict[], int &size)
{
    int i = 0;
    
    //loop for permutator
    permutatorLoop(prefix, rest, results, index, i, dict, size);
    return index;
}

//loop for permutator
void permutatorLoop(string &prefix, string &rest, string results[], int &index, int i, const string dict[], int &size)
{
    if(i >= rest.size())
        return;
    
    
    //set up for switching words around
    //get letter index is on
    string indexLetter = rest.substr(i,1);
    
    //get strings of rest without the letter removed
    string restWithoutFirstPOST = rest.substr(i + 1);
    string restWithoutFirstPRE = rest.substr(0,i);
    
    string preRestRemove = rest;
    string prePrefixAdd = prefix;
    
    
    //add the letter index is on to the prefix
    prefix += indexLetter;
    
    //remove the letter from rest
    rest = restWithoutFirstPRE + restWithoutFirstPOST;
    
    string word = prefix + rest;
    
    //check that it is in dictionary, and check that it wasn't repeated.
    if(helperCheckWord(0, size, dict, word) && !helperCheckResult(0, MAXRESULTS, results, word))
    {
        //consider results array filled, with numElements == MAXRESULTS
        if(MAXRESULTS - index == 0 )
            return;
        
        //add word into results
        results[index] = word;
        index++;
    }
    
    permutator(prefix, rest, results, index, dict, size);
    
    //reset the word
    prefix = prePrefixAdd;
    rest = preRestRemove;
    
    
    //loop again
    i += 1;
    permutatorLoop(prefix, rest, results, index, i, dict, size);
    
    
}


//this function checks if a word is in the RESULTS array
bool helperCheckResult(int i, int max, string array[], string word)
{
    if (i >= max)
        return false;
    
    
    //FIXME: dont know if i can have this bracket
    
    //if the word is in the results array
    if(array[i] == word)
    {
        return true;
    }

    //iterate the index
    return helperCheckResult(i + 1, max, array, word);
 
}


//Displays int:size number of strings from string:results. The string:results[] can be printed in
//any order.
//if size > number of objects in results, output empty string for each. DONE
void revealOutcomes(const string results[], int size)
{
    //FIXME: might have too many unnecesary base cases. Make it more efficient
    
    
    //If size is less than 0 initially, RETURN NOTHING
    if(size < 0)
    {
        return;
    }
    
    //if size is bigger than MAXRESULTS make them equal
    if(size > MAXRESULTS)
    {
        size = MAXRESULTS;
    }
    
    //base case we reach the end
    if(size == 0)
    {
    //stop recursion
    }
    else
    {
        size -= 1;
        revealOutcomes(results, size);
        //after every decrementation, we're still gonna output it
        //FIXME:COUT?
        
        if(results[size] != "")
            
            //output the words
        cout << results[size] << endl;
    }
}





