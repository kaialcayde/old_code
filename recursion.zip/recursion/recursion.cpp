#include <string>
using namespace std;

#include <iostream>


//Functions
int mTimesN(unsigned int m, unsigned int n);
int tallyTheDigits (int num, int digit);
string foursUp (string n);
string parentheticallySpeaking(string str);
bool totalEclipseOfTheHeart (const int a[], int size, int
                             target);
bool seasonFinale (string maze[], int nRows, int nCols,
                   int sr, int sc, int er, int ec);






int main(){
    string maze[10] = {
     "XXXXXXXXXX",
     "X.......@X",
     "XX@X@@.XXX",
     "X..X.X...X",
     "X..X...@.X",
     "X....XXX.X",
     "X@X....XXX",
     "X..XX.XX.X",
     "X...X....X",
     "XXXXXXXXXX"
     };

     if (seasonFinale (maze, 10, 10, 1, 1, 1, 4))
     cout << "Solvable!" << endl;
     else
     cout << "Out of luck!" << endl;
    
    cout << mTimesN(1, 0) << '\n';

cout << tallyTheDigits (55355, 5) << '\n';

cout << foursUp("aaaa") << '\n' ;

cout << parentheticallySpeaking("a(bcd)e") << '\n' ;

    int a[] = {-2,4,8};
    bool test = totalEclipseOfTheHeart(a, 3, 10);
    if(test == true)
    {
        cout << "correct" << '\n' ;
    }
    return 0;
}







//FUNCTION 1


int mTimesN(unsigned int m, unsigned int n)
{

    //base case where we don't add at all
    if(n == 0)          //need n == 0 because we are decrementing it through recursion.
    {
        return 0;
    }
    
    //base case, which will be continuously added each loop
    else if(n == 1)
    {
        return m;
    }
    
    else
    {
        //ADD ONLY
        return m + mTimesN(m, n - 1);
    }
}



//FUNCTION 2

int tallyTheDigits (int num, int digit)
{

    if(num == 0)        //base case
    {
        return 0;
    }
    
    if(num%10 == digit)         //if match
    {
        return 1 + tallyTheDigits(num/10, digit);       //return 1 to make a counter. eventually at the end when                                                 num == 0, it will be 1 + (however many more times it                                                   appears + 0 for the end
    }
    
    return tallyTheDigits(num / 10, digit);         //if no match, go back and do it again. Look for match
}



//FUNCTION 3

//length is number of letters
string foursUp (string n)
{
    
    //base case empty
    if(n.length() == 0)
    {
        return "";           //empty string
    }
    
    //base case that is foundation for the entire function
    if(n.length() == 1)
    {
        return n;
    }
    
    //if match look at last and second-to-last letter
    if(n.substr(n.length() - 1,1) == n.substr(n.length() - 2, 1))
    {
        //return recursion again but up to second to last, and then add "44" and then last letter
        return (foursUp(n.substr(0, n.length()-1)) + "44" + (n.substr(n.length()-1,1)));
    }
    
    //if don't match, return recursion again but up to the second to last, and add the last letter
    return foursUp(n.substr(0, n.length()-1)) + n.substr(n.length()-1,1);
}



//FUNCTION 4

//will always have exactly one pair of parenthases
string parentheticallySpeaking(string str)
{
    //current amount of letters, cleaner
    size_t amt = str.length();

    //if current is beginning parenthases
    if(str.substr(0,1) == "(")
    {
        if(str.substr(amt-1,1) != ")")
            return (parentheticallySpeaking(str.substr(0,amt - 1)));    //get rid of the extra letters after ")"
        return str.substr(0);       //if last char is ')' return everything from  '(' to  ')'
    }


    //if no beginning parenthases, keep returning until beginning parenthases is first
    return  (parentheticallySpeaking(str.substr(1)));
 
}



//FUNCTION 5

// Return true if the total of any combination of elements in
// the array a equals the value of the target.


//idea: get each number, then add the all numbers in the array to it starting at the very end, continuously adding number by number
bool totalEclipseOfTheHeart (const int a[], int size, int
target)
{
    //target == 0 is first so return true is prioritized
    //want target to be 0
    if (target == 0)
    {
        return true;
    }
    
    //if the target is not 0, and we have considered every element, the combination does not add up
    if (target != 0 && size == 0)
    {
        return false;
    }
    
    //none work? go back and recurse, return again
    
    //go through each element, we will consider each element to be added or not in the return statement below.
    size--;

    //for each a[size] (since we are decrementing it, we can use a[size] for each element) we can consider its effect on the target and not on the target. It will branch out to affect every number and possible combination.
    return (totalEclipseOfTheHeart(a, size, target) || totalEclipseOfTheHeart(a, size, target - a[size]));

}


//Q2


// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise
bool seasonFinale (string maze[], int nRows, int nCols,
                   int sr, int sc, int er, int ec){
    
    
    //If the start location is equal to the ending location, then
    //we've solved the maze, so return true.
    if(sr == er && sc == ec)
    {
        return true;
    }
        
        //Mark the start location as visted.
//        if(maze[sr][sc] == '.')           starting point will never be 'X' or '@' . Redundant
//        {
            maze[sr][sc] = 'V';         //update it to become visited
//        }
    
    //don't have to worry about the borders because we will never go out of bounds. If starting and end points can only be '.', it will never be out of bounds.
    
        //replace for with if statements. In each if statement, check if it is '.', which will indicate it is unvisited
    
        //south
        if(maze[sr][sc - 1] == '.')
        {
            if(seasonFinale(maze, nRows, nCols, sr, sc-1, er, ec))
            {
                return true;
            }
        }
            
        //north
        if(maze[sr][sc + 1] == '.')
        {

            if(seasonFinale(maze, nRows, nCols, sr, sc+1, er, ec))
            {
                return true;
            }

        }

        //east
        if(maze[sr-1][sc] == '.')
        {
            if(seasonFinale(maze, nRows, nCols, sr-1, sc, er, ec))
            {
                return true;
            }
        }

        //west
        if(maze[sr+1][sc] == '.')
        {
            if(seasonFinale(maze, nRows, nCols, sr+1, sc, er, ec))
            {
                return true;
            }
        }
    
        //after going through all the if statements
        return false;
    }





