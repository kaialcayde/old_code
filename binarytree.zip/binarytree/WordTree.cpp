//
//  WordTree.cpp
//  tree
//
//  Created by Kai N. Alcayde on 8/18/21.
//

#include "WordTree.h"
#include <queue>
using namespace std;


//FIXME: check empty copy
// copy constructor
//copy rhs into this
WordTree::WordTree(const WordTree& rhs){
    
    
    //FIXME:not so sure if this makes a deep copy
    //first make it nullptr so that it doesn't have random stuff in it
    //do i have to delete the stuff after it? not 100% sure, check, maybe memory leaks
    root = nullptr;
    
    //use a helper function to replace that wordNode pointer ITSELF with a whole other tree
    root = helpCopy(rhs.root);

}

//using ideas of binary tree traversal and recursively calling that
//here, i got minor help from an internet search, mostly with the idea of returning a pointer
WordNode* WordTree::helpCopy (WordNode *root)
{
    
    //base case
    //this means that it has reached that leaf, or the end of that recursive cycle.
    if(root == nullptr)
        //fr m_left and m_right
        return nullptr;
    
    //create a new node to store data
    //(once recursively called it will be nullptr, so have to set it to a new node to be able to take in values)
    WordNode* original = new WordNode();
    
    //store data
    original->m_data = root->m_data;
    original->m_count = root->m_count;
    
    //for each subtree of original that we want to copy, we have to recursively call it for each
    original->m_left  = helpCopy(root->m_left);
    original->m_right = helpCopy(root->m_right);

    //at the end after all recursive calls, we will return the built up copied tree to set equal to root
    return original;
    
}



// assignment operator

const WordTree& WordTree::operator=(const WordTree& rhs)
{
    if (this == &rhs) return *this;
    
    //copy construct a dummy copy of rhs
    WordTree dummy(rhs);
    
    //use idea of temp switching
    WordNode* dummyRoot = dummy.root;
    dummy.root = root;
    root = dummyRoot;

    return *this;
}

// Inserts v into the WordTree
void WordTree::add(WordType v)
{
    size_t ct;
    
    //make word lowercase
    for(ct = 0; ct < v.size(); ct++)
    {
        //only look at the letters
        if(isalpha(v[ct]))
        {
            //set a character to the letter and lowercase it
        char c = v[ct];
        v[ct] = tolower(c);
        }
    }
    
    //if empty
    if(root == nullptr)
    {
        //create a new node and set the root equal to that node to be able to store things into it
        WordNode* cur = new WordNode(v);
        root = cur;
        
        return;
    }
    
    //else, start at root of tree.
    WordNode* cur = root;
    for(;;)
    {
        //if word is already there
        if(v == cur->m_data)
        {
            cur->m_count++;
            return;
        }
        
        //if v is less than the current data
        if(v < cur->m_data)
        {
            //if the left isn't nullptr iterate
            if(cur->m_left != nullptr)
                cur = cur->m_left;
            else
            {
                cur->m_left = new WordNode(v);
                return;
            }
        }
        
        //if v is greater than the current data (right side of tree)
        //do similar code as above except for right side
        else if(v > cur->m_data)
        {
            //if the left isn't nullptr iterate
            if(cur->m_right != nullptr)
                cur = cur->m_right;
            else
            {
                cur->m_right = new WordNode(v);
                return;
            }
        }
    }
    
}


// Returns the number of distinct words / nodes
int WordTree::distinctWords() const
{
    //helper function will count
    return distinctIterator(root);
}

//count for disctinctWords
//here, i got minor help from the internet search in finding out that I can add and recursively call multiple things in a return statement
int WordTree::distinctIterator(WordNode* root) const
{
    //think about it logically, am doing the same logic as pre order (i think) except recursively and "processing it" everytime you hit a node
    if(root == nullptr)        //if current is empty
        return 0;

    //if not null, do recursion
    else
    {
        //do recursion on each subtree in the addition, and increment by 1 to account for every distinct word for every time you do on each and add the total for each subtree, which is incremented by 1 as well
    return(1 + distinctIterator(root->m_left) + distinctIterator(root->m_right));

    }
}



// Returns the total number of words inserted, including
// duplicate values
int WordTree::totalWords() const
{
    //helper function will count
    return iterator(root);
}


//iterator
int WordTree::iterator(WordNode* root) const
{
    //think about it logically, am doing the same logic as level order traversal except recursively and "processing it" everytime you hit a node in the return statement
    if(root == nullptr)        //if current is empty
        return 0;

    //if not null, do recursion
    else
    {
        //same idea as distinctIterator function I wrote above, except instead of adding 1 to account for solely each distinct word we add the # of elements listed for each after every recursion.
        return ((root->m_count) + iterator(root->m_left) + iterator(root->m_right));
    }
}

//this helper function is supposed to be reminicent of in order traveresal
void output(std::ostream &out, WordNode* root)
{
        if(root == NULL)
            return;
    
        //this is basically in order traversal
        output(out, root->m_left);
    
        out << root->m_data << " " << root->m_count << endl;
    
        output(out, root->m_right);
}


// Prints the WordTree
std::ostream& operator<<(std::ostream &out, const
                         WordTree& rhs)
{
    
    WordNode* p = rhs.root;
    //use a helper function to do recursion and print everything out
    output(out, p); 
    return out;
}





// Destroys all the dynamically allocated memory in the
// tree
WordTree::~WordTree()
{
    begone(root);

}

//helper function for destructor
void WordTree::begone(WordNode* p)
{
    //base case
    if(p == nullptr)
        return;

    //create a temp wordnode that will be deleted after incrementing to left and right subtrees
    WordNode* temp = p;
    WordNode* second;
    second = p->m_right;

    p = p->m_left;
    //do recursion on left
    begone(p);
    
    //this is the key, it keeps deleting after doing recursion on both sides
    delete temp;

    //do recursion on right
    begone(second);

}






