//
//  main.cpp
//  tree
//
//  Created by Kai N. Alcayde on 8/18/21.
//

#include <iostream>
#include "WordTree.h"
using namespace std;

int main() {
    return 0;
}
