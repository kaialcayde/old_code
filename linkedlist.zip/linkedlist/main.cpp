//
//  main.cpp
//  Hw1
//
//  Created by Kai N. Alcayde on 7/9/21.
//

#include "LinkedList.h"
#include <iostream>
#include <string>
using namespace std;
int main() {
    
    LinkedList e1;
    e1.insertToFront("Athos");
    e1.insertToFront("Porthos");
    e1.insertToFront("Aramis");
    LinkedList e2;
    e2.insertToFront("Robin");
    e2.insertToFront("Batman");
    e2.insertToFront("Ah");
    e2.insertToFront("Ahh");


    e1.append(e2); // adds contents of e2 to the end of e1
    string s;

    e1.printList();


//    e1 = e2;
    
//
//    assert(e1.size() == 7 && e1.get(3, s) && s == "Batman");
//    assert(e2.size() == 4 && e2.get(1, s) && s == "Robin");
    
    return 0;
}
