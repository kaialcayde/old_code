//
//  LinkedList.cpp
//  Hw1
//
//  Created by Kai N. Alcayde on 7/9/21.
//
#include "LinkedList.h"
#include <string>
#include <iostream>
using namespace std;

//constructor
LinkedList::LinkedList() {
    head = nullptr;
}



//copy constructor
LinkedList::LinkedList(const LinkedList& rhs) {

    
    head = new Node;    //for edge cases
    
    Node* other = rhs.head;
    
    //allow to transverse both
    Node* p = head;
    while(other->next != nullptr)
    {
        //set current value to one want to copy
        p->value = other->value;
        p->next = other->next;
        other = other->next;
        
        //in case p's list is shorter than the rhs
        p->next = new Node;
        p = p->next;
    }
    
    p->next = nullptr;
    

}


//destructor
// Destroys all the dynamically allocated memory
// in the list.
LinkedList::~LinkedList() {
    Node* p = head;
    while (p != nullptr)
    {
        Node* n = p->next;
        delete p;
        p = n;
    }
}



// assignment operator
const LinkedList& LinkedList::operator= (const LinkedList& rhs){

//
//    //want to delete old garb in *this, so ideally swap with a copy
//    LinkedList p(rhs);      //create a copy
//    this->swap(p);        //replace things in *this with rhs
//    return *this;
//
//    //at the end will delete p, the copied linkedlist when leaving the scope of this function
//
//}


    Node* p = head;
    Node* other = rhs.head;
    while (other != nullptr)
    {
        p->value = other->value;
        p->next = other->next;
        p = p->next;
//        delete other;
        other = other->next;
    }
    return *this;
}


// Inserts val at the front of the list
void LinkedList::insertToFront(const ItemType& val) {

    Node* p;
    p = new Node;
    p->value = val;
    p->next = head;
    head = p;
    

}



//space after each item, newline after last
// Prints the LinkedList
void LinkedList::printList() const {

    Node* p;
    p = head;
    while (p->next != nullptr)
    {
        cout << p->value << " ";
        p = p->next;
    }
    
    //when hit the last value
    cout << p->value << endl;
}



// Sets item to the value at position i in this LinkedList and return true, returns false if there is no element i
bool LinkedList::get(int i, ItemType& item) const {

    Node* p = head;
    int count = 0;

    //iterate through list until hit i'th element or hit end of list
    while (p != nullptr)
    {
        if (count == i)
        {
            item = p->value;
            return true;
        }

        p = p->next;
        count++;
    }

    //means that there is no element i
    return false;

}



// Reverses the LinkedList
void LinkedList::reverseList() {

    //main linked list
    Node* list = head;

    //copy linked list
     LinkedList* second = this;
    
    //find size
    this->size();
    
    //set nodes
    Node* sec = second->head;
    
    
    //create array to cycle through the copy and store the values
    ItemType dummy[this->size()];
    for(int i = this->size() - 1; i >= 0 ; i--)
    {
        dummy[i] = sec->value;
        sec = sec->next;
    }
    
    
    //store the values into the original linked list
    int j = 0;
    while(list != nullptr && j != this->size())
    {
        list->value = dummy[j];
        list = list->next;
        j++;
    }

}







// Prints the LinkedList in reverse order
void LinkedList::printReverse() const {
    
    if(head == NULL){
        return;
    }
    
    Node*n = new Node;
    for(int i = size() - 1; i > 0; i--){
        get(i, n->value);
        cout << n->value << " ";
    }
    get(0, n->value);
    cout << n->value << endl;
    
}






// Appends the values of other onto the end of this
// LinkedList.
void LinkedList::append(const LinkedList& other) {

    
    Node*org = head;
    if(head != nullptr)
    {
        while(org->next != nullptr)
        {
            org = org->next; //go to last ndoe
        }
    }
    
    //create another copy so original doesnt get messed up
    LinkedList temp(other);
    
    //append the copy
    org->next = temp.head;
    temp.head = nullptr;    //no dangling pointers

}


// Exchange the contents of this LinkedList with the other
// one.
void LinkedList::swap(LinkedList& other) {
    
    //cs31 concept?? temp variables, swap
    Node*p = head;
    head = other.head;
    other.head = p;
    
    //unnecesary? to prevent dangling pointers, I think its ok
    p = nullptr;
}




// Returns the number of items in the Linked List.
int LinkedList::size() const {

    Node* p = head;

    int count = 0;
    while (p != nullptr)
    {
        p = p->next;
        count++;
    }
    return count;
    
}
